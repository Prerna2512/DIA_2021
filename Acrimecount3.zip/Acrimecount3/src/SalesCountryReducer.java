import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;

public class SalesCountryReducer extends Reducer<Text, Text, Text, Text> {
    public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {

        int frequencyForCountry = 0;
        for (Text value: values) {
            frequencyForCountry += Integer.parseInt(String.valueOf(value));
        }
        String year = key.toString();
        String yearfreq = Integer.toString(frequencyForCountry);
        yearfreq= yearfreq.substring(1);
        context.write(new Text(year.substring(0,4)), new Text(yearfreq));
    }
}