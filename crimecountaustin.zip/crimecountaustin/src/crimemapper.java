import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

public class crimemapper extends Mapper<Object, Text, Text, Text> {

    int one= -1;
    public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
        String valueString = value.toString();
        if (valueString.contains("NIBRS_CODE"))
        // if (SingleCountryData.contains("NIBRS_CODE"))
        {
            return;
        }
        String[] SingleCountryData = valueString.split(":");
        //System.out.println("Th is the data line: " + valueString);
        // System.out.println("Th is the sing 0: " + SingleCountryData[0]);
        // System.out.println("Th is the sing 1: " + SingleCountryData[1]);
        // System.out.println("Th is the sing 2: " + SingleCountryData[2]);
        // System.out.println("Th is the sing 3: " + SingleCountryData[3]);
        //  System.out.println("Th is the sing 4: " + SingleCountryData[4]);
        //  System.out.println("Th is the sing 8: " + SingleCountryData[8]);
        // System.out.println("Th is length of  " + SingleCountryData.length);

        String year = SingleCountryData[7];
        context.write(new Text(year), new Text(String.valueOf(one)));
    }
}


