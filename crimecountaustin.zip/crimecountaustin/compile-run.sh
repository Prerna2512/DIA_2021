#!/bin/bash

# WARNING: This command removes previous output data,
# comment it if this behavior is not desired
hdfs dfs -rm -r $3

# Compile
hadoop com.sun.tools.javac.Main src/*.java
# Generate JAR
jar cf "$1".jar -C src .
# Execute
hadoop jar "$1".jar "$1" "$2" "$3"